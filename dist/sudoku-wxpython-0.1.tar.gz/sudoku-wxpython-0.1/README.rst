# sudoku-wxpython
Sudoku game written in wx python.

Not very usefull because there are already hundreds of Sudoku games but good to learn programming with the wxPython GUI.
